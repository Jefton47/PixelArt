#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Pixelart Editor - ООП Рефакторинг
Курсовая работа: Рефакторинг процедурного подхода к ООП

Автор: Pixelart Editor Team
Версия: 1.0.0
"""

import sys
import os

# Добавляем текущую директорию в путь (на всякий случай)
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from core import Application, Config


def print_banner():
    """Вывести баннер приложения"""
    print("=" * 60)
    print("         PIXELART EDITOR - ООП РЕФАКТОРИНГ")
    print("=" * 60)
    print(f"Размер сетки: {Config.GRID_WIDTH}x{Config.GRID_HEIGHT}")
    print(f"Размер окна: {Config.SCREEN_WIDTH}x{Config.SCREEN_HEIGHT}")
    print(f"FPS: {Config.FPS}")
    print("=" * 60)
    print()


def print_controls():
    """Вывести справку по управлению"""
    print("╔════════════════════════════════════════════════════════╗")
    print("║              УПРАВЛЕНИЕ И ГОРЯЧИЕ КЛАВИШИ              ║")
    print("╠════════════════════════════════════════════════════════╣")
    print("║ ИНСТРУМЕНТЫ:                                           ║")
    print("║   B         - Кисть (Brush)                            ║")
    print("║   E         - Ластик (Eraser)                          ║")
    print("║   G         - Заливка (Fill)                           ║")
    print("║   I         - Пипетка (Eyedropper)                     ║")
    print("║                                                        ║")
    print("║ ФАЙЛЫ:                                                 ║")
    print("║   Ctrl+S    - Быстрое сохранение                       ║")
    print("║   Save      - Сохранить проект (.txt)                  ║")
    print("║   Load      - Загрузить проект (.txt)                  ║")
    print("║   Export    - Экспорт в PNG                            ║")
    print("║                                                        ║")
    print("║ РЕДАКТИРОВАНИЕ:                                        ║")
    print("║   Ctrl+Z    - Отменить (Undo)                          ║")
    print("║   Ctrl+Y    - Повторить (Redo)                         ║")
    print("║   Ctrl+Space- Очистить холст                           ║")
    print("║                                                        ║")
    print("║ ПАЛИТРЫ:                                               ║")
    print("║   1         - Палитра 'Облик' (96 цветов)              ║")
    print("║   2         - Палитра 'Мягкие оттенки' (30 цветов)     ║")
    print("║                                                        ║")
    print("║ РАЗМЕРЫ:                                               ║")
    print("║   Слайдер   - Регулировка размера кисти/ластика (1-5)  ║")
    print("╚════════════════════════════════════════════════════════╝")
    print()


def print_architecture():
    """Вывести информацию об архитектуре"""
    print("╔════════════════════════════════════════════════════════╗")
    print("║              АРХИТЕКТУРА ПРИЛОЖЕНИЯ (ООП)              ║")
    print("╠════════════════════════════════════════════════════════╣")
    print("║ ПАТТЕРНЫ ПРОЕКТИРОВАНИЯ:                               ║")
    print("║   • MVC (Model-View-Controller)                        ║")
    print("║   • Strategy (Инструменты рисования)                   ║")
    print("║   • Singleton (Application)                            ║")
    print("║   • Command (Undo/Redo)                                ║")
    print("║   • Observer (События)                                 ║")
    print("║                                                        ║")
    print("║ СТРУКТУРА МОДУЛЕЙ:                                     ║")
    print("║   models/      - Модели данных (Grid, Cell, Palette)  ║")
    print("║   utils/       - Утилиты (Vector2D, math, files)       ║")
    print("║   tools/       - Инструменты (Brush, Eraser, Fill)     ║")
    print("║   ui/          - UI компоненты (Button, Slider)        ║")
    print("║   controllers/ - Контроллеры (Input, File, Canvas)    ║")
    print("║   core/        - Ядро приложения (Application)         ║")
    print("╚════════════════════════════════════════════════════════╝")
    print()


def check_dependencies():
    """Проверить наличие необходимых зависимостей"""
    print("Проверка зависимостей...")
    
    try:
        import pygame
        print(f"✓ Pygame {pygame.version.ver} установлен")
    except ImportError:
        print("✗ Pygame не установлен!")
        print("  Установите: pip install pygame")
        return False
    
    # Проверка модулей проекта
    modules = ['models', 'utils', 'tools', 'ui', 'controllers', 'core']
    for module in modules:
        try:
            __import__(module)
            print(f"✓ Модуль {module} найден")
        except ImportError as e:
            print(f"✗ Модуль {module} не найден!")
            print(f"  Ошибка: {e}")
            return False
    
    print("✓ Все зависимости на месте!\n")
    return True


def main():
    """Главная функция запуска приложения"""
    
    # Баннер
    print_banner()
    
    # Проверка зависимостей
    if not check_dependencies():
        print("\n❌ Невозможно запустить приложение - отсутствуют зависимости")
        sys.exit(1)
    
    # Справка
    print_controls()
    print_architecture()
    
    # Запуск приложения
    try:
        print("🚀 Запуск приложения...")
        print("   Нажмите Ctrl+C для выхода\n")
        
        app = Application()
        app.run()
        
    except KeyboardInterrupt:
        print("\n\n⚠️  Прервано пользователем (Ctrl+C)")
        sys.exit(0)
    
    except Exception as e:
        print(f"\n\n❌ Критическая ошибка: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()