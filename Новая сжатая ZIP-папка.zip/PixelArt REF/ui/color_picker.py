# ========================================
# ui/color_picker.py
# ========================================
"""Компонент выбора цвета из палитры"""

import pygame as pg
from typing import Tuple, Optional, List


class ColorPicker:
    """
    Компонент для отображения и выбора цветов из палитры
    """
    
    def __init__(self, x: int, y: int, cell_size: int = 20):
        """
        Инициализация color picker
        
        Args:
            x, y: позиция
            cell_size: размер одной цветовой ячейки
        """
        self._x = x
        self._y = y
        self._cell_size = cell_size
        self._selected_color: Optional[Tuple[int, int, int]] = None
        self._colors: List[Tuple[int, int, int]] = []
        self._positions: List[Tuple[int, int]] = []
        self._cols = 8  # Цветов в ряду
    
    def set_colors(self, colors: List[Tuple[int, int, int]]):
        """
        Установить список цветов для отображения
        
        Args:
            colors: список цветов RGB
        """
        self._colors = colors
        self._calculate_positions()
    
    def _calculate_positions(self):
        """Вычислить позиции всех цветовых ячеек"""
        self._positions = []
        for i, _ in enumerate(self._colors):
            col = i % self._cols
            row = i // self._cols
            pos_x = self._x + col * self._cell_size
            pos_y = self._y + row * self._cell_size
            self._positions.append((pos_x, pos_y))
    
    def update(self, mouse_pos: Tuple[int, int], mouse_clicked: bool) -> Optional[Tuple[int, int, int]]:
        """
        Обновить состояние (проверить клики по цветам)
        
        Args:
            mouse_pos: позиция мыши
            mouse_clicked: был ли клик
        
        Returns:
            Выбранный цвет или None
        """
        if not mouse_clicked:
            return None
        
        for i, (pos_x, pos_y) in enumerate(self._positions):
            rect = pg.Rect(pos_x, pos_y, self._cell_size, self._cell_size)
            if rect.collidepoint(mouse_pos):
                self._selected_color = self._colors[i]
                return self._selected_color
        
        return None
    
    def render(self, screen: pg.Surface):
        """Отрисовать палитру цветов"""
        for i, color in enumerate(self._colors):
            pos_x, pos_y = self._positions[i]
            pg.draw.rect(screen, color, (pos_x, pos_y, self._cell_size, self._cell_size))
            
            # Обводка для выбранного цвета
            if color == self._selected_color:
                pg.draw.rect(screen, (255, 255, 255), 
                           (pos_x - 2, pos_y - 2, self._cell_size + 4, self._cell_size + 4), 2)
    
    def __repr__(self) -> str:
        return f"ColorPicker(colors={len(self._colors)}, selected={self._selected_color})"
