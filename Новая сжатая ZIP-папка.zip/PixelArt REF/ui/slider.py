# ========================================
# ui/button.py
# ========================================
"""Компонент кнопки"""

import pygame as pg
from typing import Tuple, Optional, Callable


class Button:
    """
    Кнопка пользовательского интерфейса
    Поддерживает различные состояния и события
    """
    
    def __init__(self, x: int, y: int, width: int, height: int,
                 color: Tuple[int, int, int] = (100, 100, 100),
                 text: str = "",
                 font_size: int = 24,
                 text_color: Tuple[int, int, int] = (255, 255, 255)):
        """
        Инициализация кнопки
        
        Args:
            x, y: позиция кнопки
            width, height: размеры
            color: цвет кнопки
            text: текст на кнопке
            font_size: размер шрифта
            text_color: цвет текста
        """
        self._x = x
        self._y = y
        self._width = width
        self._height = height
        self._color = color
        self._text = text
        self._font_size = font_size
        self._text_color = text_color
        
        # Состояния
        self._hovered = False
        self._clicked = False
        self._enabled = True
        
        # Surface и шрифт
        self._surface = pg.Surface((width, height))
        self._font = pg.font.SysFont(None, font_size)
        self._text_surface = self._font.render(text, True, text_color)
        
        # Callback функция при клике
        self._on_click: Optional[Callable] = None
    
    @property
    def rect(self) -> pg.Rect:
        """Получить прямоугольник кнопки"""
        return pg.Rect(self._x, self._y, self._width, self._height)
    
    @property
    def clicked(self) -> bool:
        """Кнопка в нажатом состоянии"""
        return self._clicked
    
    @clicked.setter
    def clicked(self, value: bool):
        """Установить состояние нажатия"""
        self._clicked = value
    
    @property
    def enabled(self) -> bool:
        """Кнопка активна"""
        return self._enabled
    
    @enabled.setter
    def enabled(self, value: bool):
        """Включить/выключить кнопку"""
        self._enabled = value
    
    def set_on_click(self, callback: Callable):
        """Установить callback при клике"""
        self._on_click = callback
    
    def update(self, mouse_pos: Tuple[int, int], mouse_pressed: bool):
        """
        Обновить состояние кнопки
        
        Args:
            mouse_pos: позиция мыши
            mouse_pressed: нажата ли кнопка мыши
        """
        if not self._enabled:
            self._hovered = False
            return
        
        # Проверяем наведение
        self._hovered = self.rect.collidepoint(mouse_pos)
        
        # Обрабатываем клик
        if self._hovered and mouse_pressed:
            if self._on_click:
                self._on_click()
    
    def render(self, screen: pg.Surface):
        """
        Отрисовать кнопку
        
        Args:
            screen: поверхность для рисования
        """
        # Определяем прозрачность в зависимости от состояния
        if not self._enabled:
            alpha = 50
        elif self._clicked:
            alpha = 255
        elif self._hovered:
            alpha = 150
        else:
            alpha = 100
        
        # Рисуем фон кнопки
        self._surface.fill(self._color)
        self._surface.set_alpha(alpha)
        screen.blit(self._surface, (self._x, self._y))
        
        # Рисуем текст
        if self._text:
            text_x = self._x + 15
            text_y = self._y + (self._height - self._text_surface.get_height()) // 2
            screen.blit(self._text_surface, (text_x, text_y))
    
    def __repr__(self) -> str:
        return f"Button('{self._text}', pos=({self._x},{self._y}), size=({self._width}x{self._height}))"


# ========================================
# ui/slider.py
# ========================================
"""Компонент слайдера"""

import pygame as pg
from typing import Tuple


class Slider:
    """
    Слайдер для выбора значения в диапазоне
    """
    
    def __init__(self, x: int, y: int, width: int, height: int,
                 min_value: int = 1, max_value: int = 5,
                 initial_value: int = 3,
                 label: str = ""):
        """
        Инициализация слайдера
        
        Args:
            x, y: позиция
            width, height: размеры ползунка
            min_value: минимальное значение
            max_value: максимальное значение
            initial_value: начальное значение
            label: подпись слайдера
        """
        self._x = x
        self._y = y
        self._width = width
        self._height = height
        self._min_value = min_value
        self._max_value = max_value
        self._value = initial_value
        self._label = label
        
        # Размеры трека
        self._track_width = 120
        self._track_height = height // 2
        self._track_x = x - 60
        self._track_y = y + height // 3
        
        # Состояния
        self._dragging = False
        self._slider_x = self._calculate_slider_position()
        
        # Surface и шрифт
        self._handle_surface = pg.Surface((width, height))
        self._font = pg.font.SysFont(None, 25)
    
    @property
    def value(self) -> int:
        """Текущее значение"""
        return self._value
    
    @value.setter
    def value(self, val: int):
        """Установить значение"""
        self._value = max(self._min_value, min(self._max_value, val))
        self._slider_x = self._calculate_slider_position()
    
    def _calculate_slider_position(self) -> int:
        """Вычислить позицию ползунка на основе значения"""
        range_size = self._max_value - self._min_value
        normalized = (self._value - self._min_value) / range_size
        return int(self._track_x + normalized * self._track_width)
    
    def _calculate_value_from_position(self, x: int) -> int:
        """Вычислить значение на основе позиции"""
        # Ограничиваем x в пределах трека
        x = max(self._track_x, min(x, self._track_x + self._track_width))
        
        # Нормализуем позицию
        normalized = (x - self._track_x) / self._track_width
        
        # Вычисляем значение
        range_size = self._max_value - self._min_value
        value = self._min_value + normalized * range_size
        
        return int(round(value))
    
    def update(self, mouse_pos: Tuple[int, int], mouse_pressed: bool):
        """
        Обновить состояние слайдера
        
        Args:
            mouse_pos: позиция мыши
            mouse_pressed: нажата ли кнопка мыши
        """
        handle_rect = pg.Rect(
            self._slider_x - self._width // 2,
            self._y,
            self._width,
            self._height
        )
        
        # Начинаем перетаскивание
        if handle_rect.collidepoint(mouse_pos) and mouse_pressed:
            self._dragging = True
        
        # Перетаскиваем
        if self._dragging and mouse_pressed:
            self._value = self._calculate_value_from_position(mouse_pos[0])
            self._slider_x = self._calculate_slider_position()
        
        # Заканчиваем перетаскивание
        if not mouse_pressed:
            self._dragging = False
    
    def render(self, screen: pg.Surface):
        """Отрисовать слайдер"""
        # Фон для всей области
        pg.draw.rect(screen, (190, 190, 190), 
                    (self._track_x - 100, self._y - 30, 168, 60))
        
        # Трек
        pg.draw.rect(screen, (140, 140, 140),
                    (self._track_x, self._track_y, self._track_width, self._track_height))
        
        # Ползунок
        self._handle_surface.fill((240, 240, 240))
        screen.blit(self._handle_surface, 
                   (self._slider_x - self._width // 2, self._y))
        
        # Подпись
        if self._label:
            label_surface = self._font.render(self._label, True, (50, 50, 50))
            screen.blit(label_surface, (self._track_x - 90, self._y - 25))
        
        # Значение
        value_surface = self._font.render(str(self._value), True, (30, 30, 30))
        value_rect = pg.Rect(self._track_x - 90, self._y + 1, 20, 20)
        pg.draw.rect(screen, (220, 220, 220), value_rect)
        screen.blit(value_surface, (self._track_x - 85, self._y + 3))
    
    def __repr__(self) -> str:
        return f"Slider('{self._label}', value={self._value}, range=[{self._min_value},{self._max_value}])"
